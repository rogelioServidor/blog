<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <br>
            <br>
            <h4>Recent Posts</h4>
            <div class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <a href="#" class="list-group-item"><?php echo e($post->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <p>Zero Post</p>
                <?php endif; ?>
                
              <!-- <a href="#" class="list-group-item active">First item</a> -->
            </div>
        </div>

        <div class="col-md-10">
            <div>
                <h2>Blog Posts <button class="btn btn-primary pull-right" data-toggle="modal" data-target="#myModal">Add Post</button></h2>
            </div>
            <br>

            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <div class="panel panel-default">
                <div class="panel-heading"><h2><?php echo e($post->title); ?></h2></div>
                <div class="panel-body"><h3><?php echo e($post->body); ?></h3></div>
                <div class="panel-footer clearfix">
                
                <br>
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="media">
                        <div class="media-left">
                            <img src="https://cdn1.iconfinder.com/data/icons/ninja-things-1/1772/ninja-simple-512.png" class="media-object" style="width:60px">
                        </div>
                        <div class="media-body">
                          <h4 class="media-heading"><?php echo e($c->name); ?></h4>
                          <p><?php echo e($c->comment); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <br>
                <div class="col-md-offset-5">
                    <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-danger">Edit Post</a>
                </div>
                <!-- <a href="#" class="btn btn-danger pull-right">Edit</a> -->
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <div class="panel panel-default">
                    <div class="panel-body">Zero Post</div>
                </div>
            <?php endif; ?>
        </div>
            <!-- <div class="panel panel-default">
                <div class="panel-heading">panel heading</div>
                <div class="panel-body">panel body</div>
                <div class="panel-footer">
                    <a href="#" class="btn btn-primary">Read More</a>
                    <a href="#" class="btn btn-danger pull-right">Edit</a>
                </div>
            </div> -->
       
        <!-- <div class="col-md-10">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    You are logged in!
                </div>
            </div>
        </div> -->
    </div>
</div>






<div class="container">
 <!--  <h2>Small Modal</h2> -->
  <!-- Trigger the modal with a button -->
  <!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Small Modal</button> -->

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Post</h4>
        </div>
        <div class="modal-body">
          
            <form class="form-horizontal" action="posts" method="POST">
            <?php echo e(csrf_field()); ?>

                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                <div class="form-group">
                  <label class="control-label col-md-2" for="title">Title:</label>
                  <div class="col-md-10">
                    <input type="text" class="form-control" id="title" name="title" placeholder="Enter title">
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-md-2" for="body">Body:</label>
                  <div class="col-md-10">
                    <textarea class="form-control" rows="10" id="body" name="body" ></textarea>
                  </div>
                </div>
                <div class="form-group">        
                  <div class="col-md-offset-2 col-md-10">
                    <div class="checkbox">
                      <label><input type="checkbox" id="visible" name="visible" >Visible</label>
                    </div>
                  </div>
                </div>
                <div class="form-group">        
                  <div class="col-md-offset-2 col-md-10">
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </div>
                </div>
            </form>

        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-primary pull-left" data-dismiss="modal">Add</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div> -->
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>