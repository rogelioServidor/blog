<?php $__env->startSection('content'); ?>
	
	<div class="col-md-8 col-md-offset-2">
	<?php if(Session::has('message')): ?>
		<div class="alert alert-success text-center">
		  <strong><?php echo e(Session::get('message')); ?></strong>
		</div>
	<?php endif; ?>
	<h2>Update Settings</h2>
	<br>
		<form class="form-horizontal" action="/settings/update" method="POST">
        <?php echo e(csrf_field()); ?>

            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
            <input type="hidden" name="role" value="<?php echo e($user->role); ?>">
            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
              <label class="control-label col-md-2" for="name">Name:</label>
              <div class="col-md-10">
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" placeholder="Enter Name">

                <?php if($errors->has('name')): ?>
	              	<span class="help-block">
	              		<strong><?php echo e($errors->first('name')); ?></strong>
	              	</span>
              	<?php endif; ?>
              </div>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
              <label class="control-label col-md-2" for="email">Email:</label>
              <div class="col-md-10">
                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" placeholder="Email Address">

                <?php if($errors->has('email')): ?>
                	<span class="help-block">
                		<strong><?php echo e($errors->first('email')); ?></strong>
                	</span>
                <?php endif; ?>
              </div>
            </div>
            <div class="form-group <?php echo e($errors->has('new_password') ? 'has-error' : ''); ?>">
              <label class="control-label col-md-2" for="new_password">New Password:</label>
              <div class="col-md-10">
                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password">

                <?php if($errors->has('new_password')): ?>
                	<span class="help-block">
                		<strong><?php echo e($errors->first('new_password')); ?></strong>
                	</span>
                <?php endif; ?>
              </div>
            </div>
            <div class="form-group <?php echo e($errors->has('confirm_password') ? 'has-error' : ''); ?>">
              <label class="control-label col-md-2" for="confirm_password">Confirm New Password:</label>
              <div class="col-md-10">
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm New Password">

                <?php if($errors->has('confirm_password')): ?>
                	<span class="help-block">
                		<strong><?php echo e($errors->first('confirm_password')); ?></strong>
                	</span>
                <?php endif; ?>
              </div>
            </div>
            <div class="form-group">        
              <div class="col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Update Settings</button>
              </div>
            </div>
        </form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>