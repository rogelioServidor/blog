<?php $__env->startSection('content'); ?>
<div class="col-md-offset-1">
  <h2>Comment</h2>
</div>
<br>
  
  <div class="col-md-10 col-md-offset-1">
  <div class="panel panel-default">
    <div class="panel-heading"><h2><?php echo e($post->title); ?></h2></div>
    <div class="panel-body"><h3><?php echo e($post->body); ?></h3></div>
  <div class="panel-footer clearfix">    
  <br>
  <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <div class="media">
          <div class="media-left">
              <img src="https://cdn1.iconfinder.com/data/icons/ninja-things-1/1772/ninja-simple-512.png" class="media-object" style="width:60px">
          </div>
          <div class="media-body">
            <h4 class="media-heading"><?php echo e($c->name); ?></h4>
            <p><?php echo e($c->comment); ?></p>
          </div>
      </div>
      <hr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <div>
      <form class="form-vertical" action="/comments" method="POST">
      <?php echo e(csrf_field()); ?>

      <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
      <input type="hidden" name="name" value="<?php echo e($post->user->name); ?>">
      <input type="hidden" name="email" value="<?php echo e($post->user->email); ?>">
      <div class="form-group <?php echo e($errors->has('comment') ? 'has-error' : ''); ?>">
        <div class="col-md-12">
          <textarea class="form-control" rows="10" id="comment" name="comment" placeholder="Comment Here"></textarea>

          <?php if($errors->has('comment')): ?>
            <span class="help-block">
              <strong><?php echo e($errors->first('comment')); ?></strong>
            </span>
          <?php endif; ?>
        </div>
      </div>
      <div class="form-group">   
        <div class="col-md-12 text-center">
          <br>
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      </div>
      </form>
    </div>

    </div>
  </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>