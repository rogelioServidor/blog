<?php $__env->startSection('content2'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2">
            <br>
            <br>
            <h4>Recent Posts</h4>
            <div class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <a href="/blog/<?php echo e($post->user->name); ?>/<?php echo e($post->id); ?>" class="list-group-item"><?php echo e($post->title); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <p>Zero Post</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-10">
            <div>
                <h2><?php echo e(strtoupper($userName->name)); ?> - Blog Posts</h2>
            </div>
            <br>

            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <div class="panel panel-default">
                <div class="panel-heading"><h2><?php echo e($post->title); ?></h2></div>
                <div class="panel-body"><h3><?php echo e($post->body); ?></h3></div>
                <div class="panel-footer clearfix">
                
                <br>
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="media">
                        <div class="media-left">
                            <img src="https://cdn1.iconfinder.com/data/icons/ninja-things-1/1772/ninja-simple-512.png" class="media-object" style="width:60px">
                        </div>
                        <div class="media-body">
                          <h4 class="media-heading"><?php echo e($c->name); ?></h4>
                          <p><?php echo e($c->comment); ?></p>
                        </div>
                    </div>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                <br>
                <div class="col-md-12">
                    <a href="/blog/<?php echo e($post->user->name); ?>/<?php echo e($post->id); ?>" class="btn btn-primary">Comment</a>
                    <!-- <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-danger pull-right">Edit / Delete</a> -->
                </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <div class="panel panel-default">
                    <div class="panel-body">Zero Post</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>